#include "tree.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

/*------------------------  StaticSearchTree  -----------------------------*/
#define LEFT 0
#define RIGHT 1
#define PARENT 2

typedef struct _node {
    // Key of the node
    int key;
    // Links towards subtrees
    // Use constants LEFT, RIGHT and PARENT to access to corresponding subtree
    int links[3];
} Node;

struct _tree {
    // number of nodes in the tree
    int size;
    // node capacity (max number of node before reallocation)
    int capacity;
    // index of the root node
    int root;
    Node* tabNodes;
};

// ----- management of the node array ----- //
bool tree_reserve(StaticSearchTree *tree, int capacity) {
    Node* newnodes = realloc( tree->tabNodes, sizeof(struct _node) * capacity );
    if ( newnodes == NULL ) {
        return false;
    }
    tree->tabNodes = newnodes;
    tree->capacity = capacity;
    return true;
}

// Note due to realloc, if the link pointer is an address into the node array then, after this call, the link pointer may be invalid.
int tree_add_node(StaticSearchTree *tree, int key, int parent, int* link) {
    // Store the new node index into the given link
    *link = tree->size;
    // Check size and reallocate if needed
    if(tree->size == tree->capacity) {
        if ( !tree_reserve(tree, tree->capacity*2) ) {
            return -1;
        };
    }
    // store the node
    tree->tabNodes[tree->size].key = key;
    tree->tabNodes[tree->size].links[PARENT] = parent;
    tree->tabNodes[tree->size].links[LEFT] = tree->tabNodes[tree->size].links[RIGHT] =  -1;
    return tree->size++;
}

/** Constructor : builds an empty StaticSearchTree
 */
StaticSearchTree *tree_create() {
    StaticSearchTree* tree = malloc( sizeof(struct _tree) );
    tree->size = 0;
    tree->root = -1;
    tree->tabNodes = NULL;
    tree_reserve(tree, 1);
    return tree;
}

/** Operator : is the tree empty ?
 * tree_empty : StaticSearchTree -> boolean
 */
bool tree_empty(const StaticSearchTree *t) {
    return t->size == 0;
}

/** Operator : return the size (number of nodes) of the tree.
 * statictree_size : StaticSearchTree -> int
 */
int tree_size(const StaticSearchTree *t) {
    return t->size;
}

/** Operator : test if a node index is valid for the tree.
 * tree_isvalidnode : StaticSearchTree -> bool
 */
bool tree_isvalidnode(const StaticSearchTree *t, int node) {
    return node >= 0 && node < t->size;
}

/** Operator : return the root node of the tree
 * @pre !tree_empty(t)
 */
int tree_rootnode(const StaticSearchTree *t) {
    assert ( !tree_empty(t) );
    return t->root;
}

/** Operator : returns the left subtree of the given node.
 * @pre tree_isvalidnode(t) 
 */
int tree_left(const StaticSearchTree *t, int node) {
    assert (tree_isvalidnode(t, node));
    return t->tabNodes[node].links[LEFT];
}

/** Operator : returns the right subtree of the given node.
 * @pre tree_isvalidnode(t) 
 */
int tree_right(const StaticSearchTree *t, int node) {
    assert (tree_isvalidnode(t, node));
    return t->tabNodes[node].links[RIGHT];
}

/** Operator : returns the parent subtree of the given node.
 * @pre tree_isvalidnode(t) 
 */
int tree_parent(const StaticSearchTree *t, int node) {
    assert (tree_isvalidnode(t, node));
    return t->tabNodes[node].links[PARENT];
}

/** Operator : returns the value of the given node of the tree.
 * @pre tree_isvalidnode(t) 
 */
int tree_key(const StaticSearchTree *t, int node) {
    assert (tree_isvalidnode(t, node));
    return t->tabNodes[node].key;
}

/*********************************************************************/
/**                        Control start here                       **/
/*********************************************************************/
/**
 *  Nom :                 Prenom :               Num Etud  :
 **/

/*
 *  Barème :  
 *    - Compilation sans warnings : 2 pts
 *    - Exercice 1 : 2 pts
 *    - Exercice 2 : 2 pts
 *    - Exercice 3 : 3 pts
 *    - Exercice 4 : 5 pts
 *    - Exercice 5 : 4 pts  
 *    - 2 points supplémentaires selon la qualité, clarté et concision du code.
 */

/* 
 * Exercice 1 : implantation iterative du constructeur
 */
/** Constructor : add a new value to a StaticSearchTree.
 * @param t the tree in which the new key will be added
 * @param k the key to add
 * @return the node id of the added node
 */
int tree_add(StaticSearchTree *t, int k) {
    (void)t;(void)k;
    return -1;
}

/*
 * Exercice 1 : application d'un foncteur sur tous les noeuds map sans tenir compte de la topologie
 */
/**
 * Apply a functor on each node of the tree, independantly from the tree topology.
 * @param t the tree to visit
 * @param f the functor to apply on visited nodes
 * @param userData opaque pointer to pass to the functor
 */
void tree_map_on_nodes(const StaticSearchTree *t, VisitFunctor f, void *userData) {
        (void)t;(void)f;(void)userData;
}

/*
 * Exercice 2 : Recherche recursive d'une cle dans un arbre
 */

/**
 * search a key on a tree
 * @param t the tree to search in
 * @param k the key to search
 * @return the node index if the node is found, the value -1 if not
 */
int tree_search(const StaticSearchTree *t, int k){
    (void)t;(void)k;
    return -1;
}

/* 
 * Exerice 3 : visite iterative dans l'ordre et dans l'ordre inverse avec programmation d'ordre supérieur
 */

/* Accessors and function helper */


/** inorder visitor
 * @param t the tree to visit
 * @param f the functor to apply on visited nodes
 * @param userData opaque pointer to pass to the functor
 */
void tree_inorder(const StaticSearchTree *t, VisitFunctor f, void *userData) {
    (void)t;(void)f;(void)userData;
}

/** reverse order visitor
 * @param t the tree to visit
 * @param f the functor to apply on visited nodes
 * @param userData opaque pointer to pass to the functor
 */
void tree_reverseorder(const StaticSearchTree *t, VisitFunctor f, void *userData) {
    (void)t;(void)f;(void)userData;
}

/*
 * Exercice 4 : recherche du plus petit ancetre commun
 */
/**
 * Find the node id of the nearest common ancestor of two keys.
 * @param t the tree to visit
 * @param k1 the first key 
 * @param k2 the second key
 * @return the node index of the nearest common ancestor
 * @pre tree_search(t, k1) != -1 && tree_search(t, k2) != -1
 */
int tree_nearest_common_ancestor(const StaticSearchTree *t, int k1, int k2) {
    (void)t;(void)k1;(void)k2;
    return -1;
} 

/* 
 * Exercice 5 : calcul de la distance entre deux cles de l'arbre (nombre d'arete dans l'arbre)
 */

/**
 * return the number of edges in the tree between two keys.
 * @param t the tree to visit
 * @param k1 the first key 
 * @param k2 the second key
 * @return the number of edges between keys
 * @pre tree_search(t, k1) != -1 && tree_search(t, k2) != -1
 */
int tree_distance(const StaticSearchTree *t, int k1, int k2) {
    (void)t;(void)k1;(void)k2;
    return -1;
}
